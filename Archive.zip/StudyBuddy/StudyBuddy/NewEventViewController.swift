//
//  NewEventViewController.swift
//  StudyBuddy
//
//  Created by Jingxian Liu on 9/16/17.
//  Copyright © 2017 Jingxian Liu. All rights reserved.
//

import UIKit

protocol NewEventViewControllerDelegate{
    func myVCDidFinish(controller:NewEventViewController,text:String)
}

class NewEventViewController: UIViewController {
    var eventString = ""
    //MARK: Properties
    @IBOutlet weak var newEventNameLabel: UILabel!
    //MARK: Actions
    @IBAction func saveEventButton(_ sender: Any) {
    }
    @IBAction func eventSelectionButton(_ sender:  UIBarButtonItem) {
        newEventNameLabel.text = sender.title!
    }
    

    var delegate:NewEventViewControllerDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        newEventNameLabel.text = eventString

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
