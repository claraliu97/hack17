//
//  ViewController.swift
//  StudyBuddy
//
//  Created by Jingxian Liu on 9/16/17.
//  Copyright © 2017 Jingxian Liu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //MARK: Properties
    @IBOutlet weak var newEventButton: UIButton!
    @IBOutlet weak var newEventLabel: UILabel!
    
    //MARK: Actions
    @IBAction func addNewEvent(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any!) {
        if segue.identifier == "mySegue"{
            let vc = segue.destination as! NewEventViewController
            vc.eventString = newEventLabel.text!
        }
    }


}

